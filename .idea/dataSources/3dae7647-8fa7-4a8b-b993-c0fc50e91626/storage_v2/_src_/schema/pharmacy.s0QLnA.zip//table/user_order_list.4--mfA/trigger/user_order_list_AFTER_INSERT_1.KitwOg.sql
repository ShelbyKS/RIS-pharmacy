create definer = root@localhost trigger user_order_list_AFTER_INSERT_1
    after insert
    on user_order_list
    for each row
BEGIN
	declare med_amount_old, amount_diff integer;
    select med_amount from in_stock_for_sale where in_stock_for_sale.id_med = new.med_id into med_amount_old;
    set amount_diff = med_amount_old -  new.med_amount;
    if amount_diff > 0 then
		UPDATE in_stock_for_sale SET med_amount = amount_diff where in_stock_for_sale.id_med = new.med_id;
	else
		DELETE FROM in_stock_for_sale where in_stock_for_sale.id_med = new.med_id;
	end if;
END;

