create
    definer = root@localhost procedure sales_report(IN year int, IN month int)
BEGIN
declare sale_id1, cost1, amount1 integer;
declare done int default 0;
declare c1 cursor for 
	select idsale, cost, sum(sale_lines.amount) from sale  join sale_lines on idsale = id_sale
		where year(date)=year and month(date)=month
			group by idsale;
declare exit handler for SQLSTATE '02000' set done = 1;
open c1;
WHILE done = 0 DO
	FETCH c1 into sale_id1, cost1, amount1;
    insert sale_report values(NULL, year, month, sale_id1, cost1, amount1);
END WHILE;
close c1;

END;

