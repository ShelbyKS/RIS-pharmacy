create
    definer = root@localhost procedure orders_report(IN year int, IN month int)
BEGIN
declare order_id1, cost1, amount1 integer;
declare supp1 char;
declare done int default 0;
declare c1 cursor for 
	select idorder, id_supplier, order_.cost, sum(order_lines.amount) from order_  join order_lines using(idorder)
		where year(date1)=year and month(date1)=month
			group by order_.idorder;
declare exit handler for SQLSTATE '02000' set done = 1;
open c1;
WHILE done = 0 DO
	FETCH c1 into order_id1, supp1, cost1, amount1;
    insert order_report values(NULL, year, month, order_id1, supp1, cost1, amount1);
END WHILE;
close c1;

END;

